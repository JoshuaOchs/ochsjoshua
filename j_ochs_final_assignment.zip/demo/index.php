<?php
require 'config/config.php';

?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>XAMPP and Dreamweaver</title>
</head>
"Hello Josh!!"
<body>
</body>
</html>